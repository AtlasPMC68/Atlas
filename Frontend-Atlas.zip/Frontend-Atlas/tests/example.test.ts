import { describe, expect, test } from "vitest";

describe("math test", () => {
  test("adds 2 + 2 to equal 4", () => {
    expect(2 + 2).toBe(4);
  });
});
