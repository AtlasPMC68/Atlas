<template>
  <footer class="bg-gray-900 text-white py-8 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto text-center">
      <h3 class="text-xl font-semibold mb-4">Atlas</h3>
      <p class="text-gray-400 mb-6">
        Solution moderne pour la gestion et visualisation de cartes
      </p>
      <div class="flex justify-center space-x-6 text-sm text-gray-400">
        <a href="/" class="hover:text-white transition-colors">Accueil</a>
        <a href="#" class="hover:text-white transition-colors"
          >Fonctionnalités</a
        >
        <a href="#" class="hover:text-white transition-colors">Support</a>
        <a href="#" class="hover:text-white transition-colors">Contact</a>
      </div>
    </div>
  </footer>
</template>
