import { ref } from "vue";
import L from "leaflet";
import { smoothFreeLinePoints } from "../utils/mapUtils.js";
import { MAP_CONFIG } from "./useMapConfig.js";

export function useMapEditing(props, emit) {
  const isDeleteMode = ref(false);

  const isResizeMode = ref(false);
  const resizingShape = ref(null);

  function metersToLatLngOffsets(centerLat, halfWidthMeters, halfHeightMeters) {
    const dLat = halfHeightMeters / 111320;
    const dLng = halfWidthMeters / (111320 * Math.cos((centerLat * Math.PI) / 180));
    return { dLat, dLng };
  }

  function polygonFromCenterWidthHeight(center, widthMeters, heightMeters, shapeType) {
    const w = Number(widthMeters);
    const h = Number(heightMeters);
    if (!Number.isFinite(w) || !Number.isFinite(h) || w <= 0 || h <= 0) return null;

    if (shapeType === "square") {
      const s = Math.min(w, h);
      return polygonFromCenterWidthHeight(center, s, s, "rectangle");
    }

    const halfW = w / 2;
    const halfH = h / 2;
    const { dLat, dLng } = metersToLatLngOffsets(center.lat, halfW, halfH);

    const north = center.lat + dLat;
    const south = center.lat - dLat;
    const east = center.lng + dLng;
    const west = center.lng - dLng;

    return {
      type: "Polygon",
      coordinates: [[
        [west, north],
        [east, north],
        [east, south],
        [west, south],
        [west, north],
      ]],
    };
  }

  function circleFromCenterDiameter(center, diameterMeters) {
    const d = Number(diameterMeters);
    if (!Number.isFinite(d) || d <= 0) return null;
    const r = d / 2;

    const steps = 32;
    const pts = [];
    for (let i = 0; i < steps; i++) {
      const a = (i / steps) * 2 * Math.PI;
      const lat = center.lat + (r / 111320) * Math.sin(a);
      const lng = center.lng + ((r / 111320) * Math.cos(a)) / Math.cos((center.lat * Math.PI) / 180);
      pts.push([lng, lat]);
    }
    pts.push(pts[0]);
    return { type: "Polygon", coordinates: [pts] };
  }

  function ovalFromCenterWidthHeight(center, widthMeters, heightMeters) {
    const w = Number(widthMeters);
    const h = Number(heightMeters);
    if (!Number.isFinite(w) || !Number.isFinite(h) || w <= 0 || h <= 0) return null;

    const rx = w / 2;
    const ry = h / 2;

    const steps = 32;
    const pts = [];
    for (let i = 0; i < steps; i++) {
      const a = (i / steps) * 2 * Math.PI;
      const lat = center.lat + (ry / 111320) * Math.sin(a);
      const lng = center.lng + ((rx / 111320) * Math.cos(a)) / Math.cos((center.lat * Math.PI) / 180);
      pts.push([lng, lat]);
    }
    pts.push(pts[0]);
    return { type: "Polygon", coordinates: [pts] };
  }

  function inferShapeType(feature) {
    const st = feature?.properties?.shapeType;
    if (st) return st;
    const t = feature?.type;
    if (t === "rectangle") return "rectangle";
    if (t === "square") return "square";
    if (t === "circle") return "circle";
    if (t === "triangle") return "triangle";
    if (t === "oval") return "oval";
    if (t === "polygon") return "polygon";
    return null;
  }

  function getCenterFromLayer(layer) {
    if (layer?.getBounds) return layer.getBounds().getCenter();
    if (layer?.getLatLng) return layer.getLatLng();
    return null;
  }

  function normalizeAngleDeg(a) {
    const n = Number(a);
    if (!Number.isFinite(n)) return 0;
    let x = n % 360;
    if (x < 0) x += 360;
    return x;
  }

  function getAngleDegFromFeature(feature) {
    const p = feature?.properties || {};
    return normalizeAngleDeg(p.rotationDeg ?? p.angleDeg ?? p.angle ?? p.rotation ?? 0);
  }

  function setAngleDegOnFeature(feature, angleDeg) {
    const next = normalizeAngleDeg(angleDeg);
    return {
      ...(feature || {}),
      properties: {
        ...(feature?.properties || {}),
        rotationDeg: next,
      },
    };
  }

  function rotatePoint(pt, centerPt, rad) {
    const dx = pt.x - centerPt.x;
    const dy = pt.y - centerPt.y;
    const c = Math.cos(rad);
    const s = Math.sin(rad);
    return L.point(centerPt.x + dx * c - dy * s, centerPt.y + dx * s + dy * c);
  }

  function rotatePointsTree(pts, centerPt, rad) {
    if (Array.isArray(pts)) return pts.map((x) => rotatePointsTree(x, centerPt, rad));
    return rotatePoint(pts, centerPt, rad);
  }

  function latlngsToPoints(map, latlngs) {
    if (Array.isArray(latlngs)) return latlngs.map((x) => latlngsToPoints(map, x));
    return map.latLngToLayerPoint(latlngs);
  }

  function pointsToLatlngs(map, pts) {
    if (Array.isArray(pts)) return pts.map((x) => pointsToLatlngs(map, x));
    return map.layerPointToLatLng(pts);
  }

  function geometryFromLayer(layer) {
    if (layer.getLatLng && !layer.getLatLngs) {
      const ll = layer.getLatLng();
      return { type: "Point", coordinates: [ll.lng, ll.lat] };
    }

    if (layer.getLatLngs) {
      const latlngs = layer.getLatLngs();

      const isPolygon = layer instanceof L.Polygon || layer instanceof L.Rectangle;

      if (!isPolygon) {
        const coords = latlngs.map((ll) => [ll.lng, ll.lat]);
        return { type: "LineString", coordinates: coords };
      }

      const ring = latlngs[0] ?? latlngs;
      const coords = ring.map((ll) => [ll.lng, ll.lat]);

      if (coords.length && (coords[0][0] !== coords[coords.length - 1][0] || coords[0][1] !== coords[coords.length - 1][1])) {
        coords.push(coords[0]);
      }
      return { type: "Polygon", coordinates: [coords] };
    }

    return null;
  }

  async function applyResizeFromDims(featureId, widthMeters, heightMeters, map, featureLayerManager) {
    const fid = String(featureId);

    const layer = featureLayerManager.layers.get(fid);
    if (!layer) return;

    const feature =
      props.features.find((f) => String(f.id) === fid) ||
      layer.feature ||
      null;
    if (!feature) return;

    const center = feature?.properties?.center
      ? L.latLng(feature.properties.center.lat, feature.properties.center.lng)
      : getCenterFromLayer(layer);
    if (!center) return;

    const shapeType = inferShapeType(feature);
    if (!shapeType) return;

    if (shapeType === "square") {
      const w = Number(widthMeters);
      const h = Number(heightMeters);
      const side = (Number.isFinite(w) && w > 0) ? w : ((Number.isFinite(h) && h > 0) ? h : null);
      if (!side) return;
      widthMeters = side;
      heightMeters = side;
    }

    const w = Number(widthMeters);
    const h = Number(heightMeters);

    const hasW = Number.isFinite(w) && w > 0;
    const hasH = Number.isFinite(h) && h > 0;

    const d = hasW ? w : (hasH ? h : null);
    if (shapeType === "circle" && (d == null || d <= 0)) return;
    if (shapeType !== "circle" && !hasW && !hasH) return;

    let newGeom = null;

    if (shapeType === "circle") {
      newGeom = circleFromCenterDiameter({ lat: center.lat, lng: center.lng }, d);
    } else if (shapeType === "oval") {
      newGeom = ovalFromCenterWidthHeight({ lat: center.lat, lng: center.lng }, hasW ? w : null, hasH ? h : null);
    } else if (shapeType === "triangle") {
      const candidates = [];
      if (hasW) candidates.push(w / Math.sqrt(3));
      if (hasH) candidates.push(h / 1.5);
      if (!candidates.length) return;

      const R = candidates.reduce((a, b) => a + b, 0) / candidates.length;

      const points = [];
      for (let i = 0; i < 3; i++) {
        const angle = ((i * 120 + 90) * Math.PI) / 180;
        const lat = center.lat + (R / 111320) * Math.sin(angle);
        const lng = center.lng + ((R / 111320) * Math.cos(angle)) / Math.cos((center.lat * Math.PI) / 180);
        points.push([lng, lat]);
      }
      points.push(points[0]);
      newGeom = { type: "Polygon", coordinates: [points] };
    } else {
      newGeom = polygonFromCenterWidthHeight(
        { lat: center.lat, lng: center.lng },
        hasW ? w : null,
        hasH ? h : null,
        shapeType
      );
    }

    if (!newGeom) return;

    if (shapeType === "circle" && typeof layer.setRadius === "function") {
      if (typeof layer.setLatLng === "function") layer.setLatLng(center);
      layer.setRadius(d / 2);
    } else if (typeof layer.setLatLngs === "function") {
      const ringLatLngs = newGeom.coordinates[0].map(([lng, lat]) => L.latLng(lat, lng));
      layer.setLatLngs([ringLatLngs]);
      featureLayerManager.applyRotationForFeatureId(fid);
    } else if (typeof layer.setBounds === "function") {
      const ringLatLngs = newGeom.coordinates[0].map(([lng, lat]) => L.latLng(lat, lng));
      layer.setBounds(L.latLngBounds(ringLatLngs));
      featureLayerManager.applyRotationForFeatureId(fid);
    } else {
      return;
    }

    const isTemp = fid.startsWith("temp_") || feature._isTemporary === true;
    if (isTemp) {
      layer.feature = {
        ...(layer.feature || feature),
        geometry: newGeom,
        properties: {
          ...(feature.properties || {}),
          resizable: true,
          shapeType,
          center: { lat: center.lat, lng: center.lng },
          rotationDeg: feature?.properties?.rotationDeg ?? 0,
        },
      };
      return;
    }

    try {
      const updateData = {
        geometry: newGeom,
        color: feature.color ?? null,
        opacity: feature.opacity ?? null,
        stroke_width: feature.stroke_width ?? null,
        properties: {
          ...(feature.properties || {}),
          resizable: true,
          shapeType,
          center: { lat: center.lat, lng: center.lng },
          rotationDeg: feature?.properties?.rotationDeg ?? 0,
        },
      };

      const response = await fetch(`${import.meta.env.VITE_API_URL}/maps/features/${fid}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updateData),
      });

      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

      const updatedFeature = await response.json();

      const idx = props.features.findIndex((f) => String(f.id) === fid);
      if (idx !== -1) {
        const updatedFeatures = [...props.features];
        updatedFeatures[idx] = updatedFeature;
        emit("features-loaded", updatedFeatures);
      }
    } catch (err) {
      console.error("Error resizing feature:", err);
    }
  }

  // ==========================
  // NEW: ROTATION (angle absolu)
  // ==========================
    // ==========================
  // NEW: ROTATION (angle absolu)
  // ==========================
  async function applyRotateFromAngle(featureId, angleDeg, map, featureLayerManager) {
    const fid = String(featureId);

    const layer = featureLayerManager.layers.get(fid);
    if (!layer) return;

    const feature =
      props.features.find((f) => String(f.id) === fid) ||
      layer.feature ||
      null;
    if (!feature) return;

    const nextAngle = normalizeAngleDeg(angleDeg);

    // Persist angle on the feature + layer
    if (!feature.properties) feature.properties = {};
    feature.properties.rotationDeg = nextAngle;

    if (!layer.feature) layer.feature = feature;
    else {
      layer.feature.properties = layer.feature.properties || {};
      layer.feature.properties.rotationDeg = nextAngle;
    }

    // Visual-only rotation: keep geometry coordinates unchanged
    featureLayerManager.applyRotationForFeatureId(fid);

    const isTemp = fid.startsWith("temp_") || feature._isTemporary === true;
    if (isTemp) return;

    try {
      const geom = geometryFromLayer(layer);
      const updateData = {
        geometry: geom,
        color: feature.color ?? null,
        opacity: feature.opacity ?? null,
        stroke_width: feature.stroke_width ?? null,
        properties: {
          ...(feature.properties || {}),
          rotationDeg: nextAngle,
        },
      };

      const response = await fetch(`${import.meta.env.VITE_API_URL}/maps/features/${fid}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updateData),
      });

      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

      const updatedFeature = await response.json();
      const idx = props.features.findIndex((f) => String(f.id) === fid);
      if (idx !== -1) {
        const updatedFeatures = [...props.features];
        updatedFeatures[idx] = updatedFeature;
        emit("features-loaded", updatedFeatures);
      }
    } catch (err) {
      console.error("Error rotating feature:", err);
    }
  }

  // ===== SHAPE CREATION FUNCTIONS =====
  function createSquare(center, sizePoint, map, layersComposable) {
    const centerPixel = map.latLngToContainerPoint(center);
    const sizePixel = map.latLngToContainerPoint(sizePoint);

    const pixelDistance = centerPixel.distanceTo(sizePixel);
    const halfSidePixels = pixelDistance / Math.sqrt(2);

    const topLeftPixel = L.point(centerPixel.x - halfSidePixels, centerPixel.y - halfSidePixels);
    const bottomRightPixel = L.point(centerPixel.x + halfSidePixels, centerPixel.y + halfSidePixels);

    const topLeft = map.containerPointToLatLng(topLeftPixel);
    const bottomRight = map.containerPointToLatLng(bottomRightPixel);

    const square = L.rectangle(
      [
        [topLeft.lat, topLeft.lng],
        [bottomRight.lat, bottomRight.lng],
      ],
      { color: "#000000", weight: 2, fillColor: "#cccccc", fillOpacity: 0.5 }
    );

    layersComposable.drawnItems.value.addLayer(square);

    const feature = squareToFeatureFromCenter(center, sizePoint, map);

    const tempFeature = {
      ...feature,
      id: `temp_${Date.now()}_${Math.random()}`,
      _isTemporary: true,
    };

    square.feature = tempFeature;

    layersComposable.featureLayerManager.layers.set(tempFeature.id, square);
    layersComposable.featureLayerManager.makeLayerClickable(tempFeature.id, square);
  }

  function createRectangle(startCorner, endCorner, map, layersComposable) {
    const minLat = Math.min(startCorner.lat, endCorner.lat);
    const maxLat = Math.max(startCorner.lat, endCorner.lat);
    const minLng = Math.min(startCorner.lng, endCorner.lng);
    const maxLng = Math.max(startCorner.lng, endCorner.lng);

    const rectangle = L.rectangle(
      [
        [minLat, minLng],
        [maxLat, maxLng],
      ],
      { color: "#000000", weight: 2, fillColor: "#cccccc", fillOpacity: 0.5 }
    );

    layersComposable.drawnItems.value.addLayer(rectangle);

    const feature = rectangleToFeatureFromCorners(startCorner, endCorner);

    const tempFeature = {
      ...feature,
      id: `temp_${Date.now()}_${Math.random()}`,
      _isTemporary: true,
      properties: {
        ...(feature.properties || {}),
        rotationDeg: 0,
      },
    };

    rectangle.feature = tempFeature;

    layersComposable.featureLayerManager.layers.set(tempFeature.id, rectangle);
    layersComposable.featureLayerManager.makeLayerClickable(tempFeature.id, rectangle);
  }

  function createCircle(center, edgePoint, map, layersComposable) {
    const radius = map.distance(center, edgePoint);

    const circle = L.circle(center, {
      radius,
      color: "#000000",
      weight: 2,
      fillColor: "#cccccc",
      fillOpacity: 0.5,
    });

    layersComposable.drawnItems.value.addLayer(circle);

    const feature = circleToFeatureFromCenter(center, edgePoint, map);

    const tempFeature = {
      ...feature,
      id: `temp_${Date.now()}_${Math.random()}`,
      _isTemporary: true,
    };

    circle.feature = tempFeature;

    layersComposable.featureLayerManager.layers.set(tempFeature.id, circle);
    layersComposable.featureLayerManager.makeLayerClickable(tempFeature.id, circle);
  }

  function createTriangle(center, sizePoint, map, layersComposable) {
    const distance = map.distance(center, sizePoint);

    const points = [];
    for (let i = 0; i < 3; i++) {
      const angle = ((i * 120 + 90) * Math.PI) / 180;
      const lat = center.lat + (distance / 111320) * Math.sin(angle);
      const lng =
        center.lng +
        ((distance / 111320) * Math.cos(angle)) /
          Math.cos((center.lat * Math.PI) / 180);
      points.push([lat, lng]);
    }

    const triangle = L.polygon(points, {
      color: "#000000",
      weight: 2,
      fillColor: "#cccccc",
      fillOpacity: 0.5,
    });

    layersComposable.drawnItems.value.addLayer(triangle);

    const feature = triangleToFeatureFromCenter(center, sizePoint, map);

    const tempFeature = {
      ...feature,
      id: `temp_${Date.now()}_${Math.random()}`,
      _isTemporary: true,
    };

    triangle.feature = tempFeature;

    layersComposable.featureLayerManager.layers.set(tempFeature.id, triangle);
    layersComposable.featureLayerManager.makeLayerClickable(tempFeature.id, triangle);
  }

  function createOval(center, heightPoint, widthPoint, map, layersComposable) {
    const heightRadius = Math.abs(center.lat - heightPoint.lat) * 111320;
    const widthRadius =
      Math.abs(center.lng - widthPoint.lng) *
      111320 *
      Math.cos((center.lat * Math.PI) / 180);

    const points = [];
    const steps = 32;
    for (let i = 0; i < steps; i++) {
      const angle = (i / steps) * 2 * Math.PI;
      const lat = center.lat + (heightRadius / 111320) * Math.sin(angle);
      const lng =
        center.lng +
        ((widthRadius / 111320) * Math.cos(angle)) /
          Math.cos((center.lat * Math.PI) / 180);
      points.push([lat, lng]);
    }

    const oval = L.polygon(points, {
      color: "#000000",
      weight: 2,
      fillColor: "#cccccc",
      fillOpacity: 0.5,
    });

    layersComposable.drawnItems.value.addLayer(oval);

    const feature = ovalToFeatureFromCenter(center, heightPoint, widthPoint);

    const tempFeature = {
      ...feature,
      id: `temp_${Date.now()}_${Math.random()}`,
      _isTemporary: true,
      properties: {
        ...(feature.properties || {}),
        rotationDeg: 0,
      },
    };

    oval.feature = tempFeature;

    layersComposable.featureLayerManager.layers.set(tempFeature.id, oval);
    layersComposable.featureLayerManager.makeLayerClickable(tempFeature.id, oval);
  }

  function createPointAt(latlng, map, layersComposable) {
    const currentZoom = map.getZoom();
    const radius = getRadiusForZoom(currentZoom);

    const circle = L.circleMarker(latlng, {
      radius,
      fillColor: "#000000",
      color: "#333333",
      weight: 1,
      opacity: 0.8,
      fillOpacity: 0.8,
      draggable: true,
    });

    layersComposable.allCircles.value.add(circle);
    layersComposable.drawnItems.value.addLayer(circle);

    const feature = {
      map_id: props.mapId,
      type: "point",
      geometry: { type: "Point", coordinates: [latlng.lng, latlng.lat] },
      color: "#000000",
      opacity: 0.8,
      z_index: 1,
      properties: { rotationDeg: 0, mapElementType: "point" },
    };

    const tempFeature = {
      ...feature,
      id: `temp_${Date.now()}_${Math.random()}`,
      _isTemporary: true,
    };

    circle.feature = tempFeature;

    layersComposable.featureLayerManager.layers.set(tempFeature.id, circle);
    layersComposable.featureLayerManager.makeLayerClickable(tempFeature.id, circle);
  }

  function createLine(startLatLng, endLatLng, map, layersComposable) {
    const line = L.polyline([startLatLng, endLatLng], {
      color: "#000000",
      weight: 2,
      opacity: 1.0,
    });

    layersComposable.drawnItems.value.addLayer(line);

    const feature = {
      map_id: props.mapId,
      type: "polyline",
      geometry: {
        type: "LineString",
        coordinates: [
          [startLatLng.lng, startLatLng.lat],
          [endLatLng.lng, endLatLng.lat],
        ],
      },
      color: "#000000",
      stroke_width: 2,
      opacity: 1.0,
      z_index: 1,
      properties: { rotationDeg: 0, mapElementType: "polyline" },
    };

    const tempFeature = {
      ...feature,
      id: `temp_${Date.now()}_${Math.random()}`,
      _isTemporary: true,
    };

    line.feature = tempFeature;

    layersComposable.featureLayerManager.layers.set(tempFeature.id, line);
    layersComposable.featureLayerManager.makeLayerClickable(tempFeature.id, line);
  }

  function createPolygon(points, map, layersComposable) {
    const polygon = L.polygon(points, {
      color: "#000000",
      weight: 2,
      fillColor: "#cccccc",
      fillOpacity: 0.5,
    });

    layersComposable.drawnItems.value.addLayer(polygon);

    const feature = {
      map_id: props.mapId,
      type: "polygon",
      geometry: {
        type: "Polygon",
        coordinates: [points.map((p) => [p.lng, p.lat])],
      },
      color: "#cccccc",
      opacity: 0.5,
      z_index: 1,
      properties: { rotationDeg: 0, mapElementType: "zone", shapeType: "polygon" },
    };

    const tempFeature = {
      ...feature,
      id: `temp_${Date.now()}_${Math.random()}`,
      _isTemporary: true,
    };

    polygon.feature = tempFeature;

    layersComposable.featureLayerManager.layers.set(tempFeature.id, polygon);
    layersComposable.featureLayerManager.makeLayerClickable(tempFeature.id, polygon);
  }

  function finishFreeLine(freeLinePoints, tempFreeLine, map, layersComposable) {
    if (freeLinePoints.length < 2) return;

    const smoothedPoints = smoothFreeLinePoints(freeLinePoints);

    if (tempFreeLine) layersComposable.drawnItems.value.removeLayer(tempFreeLine);

    const freeLine = L.polyline(smoothedPoints, {
      color: "#000000",
      weight: 2,
      opacity: 1.0,
    });

    layersComposable.drawnItems.value.addLayer(freeLine);

    const feature = {
      map_id: props.mapId,
      type: "polyline",
      geometry: {
        type: "LineString",
        coordinates: smoothedPoints.map((point) => [point.lng, point.lat]),
      },
      color: "#000000",
      stroke_width: 2,
      opacity: 1.0,
      z_index: 1,
      properties: { rotationDeg: 0, mapElementType: "polyline" },
    };

    const tempId = `temp_freeline_${Date.now()}_${Math.random()}`;
    const tempFeature = { ...feature, id: tempId, _isTemporary: true };

    freeLine.feature = tempFeature;

    layersComposable.featureLayerManager.layers.set(tempId, freeLine);
    if (props.editMode) {
      layersComposable.featureLayerManager.makeLayerClickable(tempId, freeLine);
    }
  }

  // ===== TEMPORARY SHAPE UPDATE FUNCTIONS =====
  function updateTempSquareFromCenter(center, sizePoint, map, layersComposable, tempShape) {
    if (tempShape) layersComposable.drawnItems.value.removeLayer(tempShape);

    const centerPixel = map.latLngToContainerPoint(center);
    const sizePixel = map.latLngToContainerPoint(sizePoint);
    const pixelDistance = centerPixel.distanceTo(sizePixel);
    const halfSidePixels = pixelDistance / Math.sqrt(2);

    const topLeftPixel = L.point(centerPixel.x - halfSidePixels, centerPixel.y - halfSidePixels);
    const bottomRightPixel = L.point(centerPixel.x + halfSidePixels, centerPixel.y + halfSidePixels);

    const topLeft = map.containerPointToLatLng(topLeftPixel);
    const bottomRight = map.containerPointToLatLng(bottomRightPixel);

    const newTempShape = L.rectangle(
      [
        [topLeft.lat, topLeft.lng],
        [bottomRight.lat, bottomRight.lng],
      ],
      { color: "#000000", weight: 2, fillColor: "#cccccc", fillOpacity: 0.5 }
    );

    layersComposable.drawnItems.value.addLayer(newTempShape);
    return newTempShape;
  }

  function updateTempRectangleFromCorners(startCorner, endCorner, map, layersComposable, tempShape) {
    if (tempShape) layersComposable.drawnItems.value.removeLayer(tempShape);

    const minLat = Math.min(startCorner.lat, endCorner.lat);
    const maxLat = Math.max(startCorner.lat, endCorner.lat);
    const minLng = Math.min(startCorner.lng, endCorner.lng);
    const maxLng = Math.max(startCorner.lng, endCorner.lng);

    const newTempShape = L.rectangle(
      [
        [minLat, minLng],
        [maxLat, maxLng],
      ],
      { color: "#000000", weight: 2, fillColor: "#cccccc", fillOpacity: 0.5 }
    );

    layersComposable.drawnItems.value.addLayer(newTempShape);
    return newTempShape;
  }

  function updateTempCircleFromCenter(center, edgePoint, map, layersComposable, tempShape) {
    if (tempShape) layersComposable.drawnItems.value.removeLayer(tempShape);

    const radius = map.distance(center, edgePoint);

    const newTempShape = L.circle(center, {
      radius,
      color: "#000000",
      weight: 2,
      fillColor: "#cccccc",
      fillOpacity: 0.5,
    });

    layersComposable.drawnItems.value.addLayer(newTempShape);
    return newTempShape;
  }

  function updateTempTriangleFromCenter(center, sizePoint, map, layersComposable, tempShape) {
    if (tempShape) layersComposable.drawnItems.value.removeLayer(tempShape);

    const distance = map.distance(center, sizePoint);

    const points = [];
    for (let i = 0; i < 3; i++) {
      const angle = ((i * 120 + 90) * Math.PI) / 180;
      const lat = center.lat + (distance / 111320) * Math.sin(angle);
      const lng =
        center.lng +
        ((distance / 111320) * Math.cos(angle)) /
          Math.cos((center.lat * Math.PI) / 180);
      points.push([lat, lng]);
    }

    const newTempShape = L.polygon(points, {
      color: "#000000",
      weight: 2,
      fillColor: "#cccccc",
      fillOpacity: 0.5,
    });

    layersComposable.drawnItems.value.addLayer(newTempShape);
    return newTempShape;
  }

  function updateTempOvalHeight(center, heightPoint, map, layersComposable, tempShape) {
    if (tempShape) layersComposable.drawnItems.value.removeLayer(tempShape);

    const radius = Math.abs(center.lat - heightPoint.lat) * 111320;

    const newTempShape = L.circle(center, {
      radius,
      color: "#000000",
      weight: 2,
      fillColor: "#cccccc",
      fillOpacity: 0.5,
    });

    layersComposable.drawnItems.value.addLayer(newTempShape);
    return newTempShape;
  }

  function updateTempOvalWidth(center, heightPoint, widthPoint, map, layersComposable, tempShape) {
    if (tempShape) layersComposable.drawnItems.value.removeLayer(tempShape);

    const heightRadius = Math.abs(center.lat - heightPoint.lat) * 111320;
    const widthRadius =
      Math.abs(center.lng - widthPoint.lng) *
      111320 *
      Math.cos((center.lat * Math.PI) / 180);

    const points = [];
    const steps = 32;
    for (let i = 0; i < steps; i++) {
      const angle = (i / steps) * 2 * Math.PI;
      const lat = center.lat + (heightRadius / 111320) * Math.sin(angle);
      const lng =
        center.lng +
        ((widthRadius / 111320) * Math.cos(angle)) /
          Math.cos((center.lat * Math.PI) / 180);
      points.push([lat, lng]);
    }

    const newTempShape = L.polygon(points, {
      color: "#000000",
      weight: 2,
      fillColor: "#cccccc",
      fillOpacity: 0.5,
    });

    layersComposable.drawnItems.value.addLayer(newTempShape);
    return newTempShape;
  }

  // ===== FEATURE CONVERSION FUNCTIONS =====
  function squareToFeatureFromCenter(center, sizePoint, map) {
    const distance = map.distance(center, sizePoint);
    const halfSide = distance / Math.sqrt(2);

    const latOffset = halfSide / 111320;
    const lngOffset = halfSide / (111320 * Math.cos((center.lat * Math.PI) / 180));

    const geometry = {
      type: "Polygon",
      coordinates: [
        [
          [center.lng - lngOffset, center.lat + latOffset],
          [center.lng + lngOffset, center.lat + latOffset],
          [center.lng + lngOffset, center.lat - latOffset],
          [center.lng - lngOffset, center.lat - latOffset],
          [center.lng - lngOffset, center.lat + latOffset],
        ],
      ],
    };

    return {
      map_id: props.mapId,
      type: "square",
      geometry,
      color: "#cccccc",
      opacity: 0.5,
      z_index: 1,
      properties: {
        shapeType: "square",
        center: { lat: center.lat, lng: center.lng },
        size: distance,
        resizable: true,
        rotationDeg: 0,
        mapElementType: "shape",
        shapeKind: "square",
      },
    };
  }

  function rectangleToFeatureFromCorners(startCorner, endCorner) {
    const minLat = Math.min(startCorner.lat, endCorner.lat);
    const maxLat = Math.max(startCorner.lat, endCorner.lat);
    const minLng = Math.min(startCorner.lng, endCorner.lng);
    const maxLng = Math.max(startCorner.lng, endCorner.lng);

    const geometry = {
      type: "Polygon",
      coordinates: [
        [
          [minLng, maxLat],
          [maxLng, maxLat],
          [maxLng, minLat],
          [minLng, minLat],
          [minLng, maxLat],
        ],
      ],
    };

    return {
      map_id: props.mapId,
      type: "rectangle",
      geometry,
      color: "#cccccc",
      opacity: 0.5,
      z_index: 1,
      properties: {
        rotationDeg: 0,
        mapElementType: "shape",
        shapeKind: "rectangle",
        shapeType: "rectangle",
      },
    };
  }

  function circleToFeatureFromCenter(center, edgePoint, map) {
    const radius = map.distance(center, edgePoint);

    const points = [];
    const steps = 32;
    for (let i = 0; i < steps; i++) {
      const angle = (i / steps) * 2 * Math.PI;
      const lat = center.lat + (radius / 111320) * Math.sin(angle);
      const lng =
        center.lng +
        ((radius / 111320) * Math.cos(angle)) /
          Math.cos((center.lat * Math.PI) / 180);
      points.push([lng, lat]);
    }
    points.push(points[0]);

    const geometry = { type: "Polygon", coordinates: [points] };

    return {
      map_id: props.mapId,
      type: "circle",
      geometry,
      color: "#cccccc",
      opacity: 0.5,
      z_index: 1,
      properties: {
        shapeType: "circle",
        center: { lat: center.lat, lng: center.lng },
        size: radius,
        resizable: true,
        rotationDeg: 0,
        mapElementType: "shape",
        shapeKind: "circle",
      },
    };
  }

  function triangleToFeatureFromCenter(center, sizePoint, map) {
    const distance = map.distance(center, sizePoint);

    const points = [];
    for (let i = 0; i < 3; i++) {
      const angle = ((i * 120 + 90) * Math.PI) / 180;
      const lat = center.lat + (distance / 111320) * Math.sin(angle);
      const lng =
        center.lng +
        ((distance / 111320) * Math.cos(angle)) /
          Math.cos((center.lat * Math.PI) / 180);
      points.push([lng, lat]);
    }
    points.push(points[0]);

    const geometry = { type: "Polygon", coordinates: [points] };

    return {
      map_id: props.mapId,
      type: "triangle",
      geometry,
      color: "#cccccc",
      opacity: 0.5,
      z_index: 1,
      properties: {
        shapeType: "triangle",
        center: { lat: center.lat, lng: center.lng },
        size: distance,
        resizable: true,
        rotationDeg: 0,
        mapElementType: "shape",
        shapeKind: "triangle",
      },
    };
  }

  function ovalToFeatureFromCenter(center, heightPoint, widthPoint) {
    const heightRadius = Math.abs(center.lat - heightPoint.lat) * 111320;
    const widthRadius =
      Math.abs(center.lng - widthPoint.lng) *
      111320 *
      Math.cos((center.lat * Math.PI) / 180);

    const points = [];
    const steps = 32;
    for (let i = 0; i < steps; i++) {
      const angle = (i / steps) * 2 * Math.PI;
      const lat = center.lat + (heightRadius / 111320) * Math.sin(angle);
      const lng =
        center.lng +
        ((widthRadius / 111320) * Math.cos(angle)) /
          Math.cos((center.lat * Math.PI) / 180);
      points.push([lng, lat]);
    }
    points.push(points[0]);

    const geometry = { type: "Polygon", coordinates: [points] };

    return {
      map_id: props.mapId,
      type: "oval",
      geometry,
      color: "#cccccc",
      opacity: 0.5,
      z_index: 1,
      properties: {
        rotationDeg: 0,
        mapElementType: "shape",
        shapeKind: "oval",
        shapeType: "oval",
      },
    };
  }

  // ===== SELECTION AND VISUAL MANAGEMENT =====
  function updateFeatureSelectionVisual(map, layerManager, selectedFeatures) {
    if (!map || !layerManager) return;

    layerManager.layers.forEach((layer, featureId) => {
      const fid = String(featureId);

      if (selectedFeatures.has(fid)) {
        if (layer instanceof L.CircleMarker) {
          layer.setStyle({ color: "#ff6b6b", weight: 3, fillColor: "#ff6b6b", fillOpacity: 0.8 });
        } else if (layer instanceof L.Polygon || layer instanceof L.Rectangle) {
          layer.setStyle({
            color: "#ff6b6b",
            weight: 3,
            fillColor: layer.options.fillColor,
            fillOpacity: layer.options.fillOpacity,
          });
        } else if (layer instanceof L.Polyline) {
          layer.setStyle({ color: "#ff6b6b", weight: 4 });
        }
      } else {
        if (layer.__atlas_originalStyle && layer.setStyle) {
          layer.setStyle(layer.__atlas_originalStyle);
        } else if (layer.setStyle) {
          const feature = props.features.find((f) => String(f.id) === fid);
          const defaultBorderColor = "#000000";
          const defaultFillColor = "#cccccc";
          const defaultOpacity = 0.5;
          const defaultStrokeWidth = 2;

          if (layer instanceof L.CircleMarker) {
            layer.setStyle({
              color: feature?.color || defaultBorderColor,
              weight: 1,
              fillColor: feature?.color || defaultBorderColor,
              fillOpacity: feature?.opacity ?? 0.8,
            });
          } else if (layer instanceof L.Polygon || layer instanceof L.Rectangle) {
            layer.setStyle({
              color: feature?.color || defaultBorderColor,
              weight: 2,
              fillColor: feature?.color || defaultFillColor,
              fillOpacity: feature?.opacity ?? defaultOpacity,
            });
          } else if (layer instanceof L.Polyline) {
            layer.setStyle({
              color: feature?.color || defaultBorderColor,
              weight: feature?.stroke_width ?? defaultStrokeWidth,
              opacity: feature?.opacity ?? 1,
            });
          }
        }
      }
    });
  }

  // ===== CRUD OPERATIONS =====
  async function updateFeaturePosition(feature, deltaLat, deltaLng) {
    try {
      const updatedGeometry = updateGeometryCoordinates(feature.geometry, deltaLat, deltaLng);
      const updateData = { geometry: updatedGeometry };

      const response = await fetch(`${import.meta.env.VITE_API_URL}/maps/features/${feature.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updateData),
      });

      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

      const updatedFeature = await response.json();

      const featureIndex = props.features.findIndex((f) => f.id === feature.id);
      if (featureIndex !== -1) {
        const updatedFeatures = [...props.features];
        updatedFeatures[featureIndex] = updatedFeature;
        emit("features-loaded", updatedFeatures);
      }
    } catch (error) {
      console.error("Error updating feature position:", error);
    }
  }

  async function deleteSelectedFeatures(selectedFeatures, featureLayerManager, map, emit) {
    if (selectedFeatures.size === 0) return;

    const featuresToDelete = Array.from(selectedFeatures);

    for (const featureId of featuresToDelete) {
      const layer = featureLayerManager.layers.get(String(featureId));
      if (layer) {
        map.removeLayer(layer);
        featureLayerManager.layers.delete(String(featureId));
      }
    }

    for (const featureId of featuresToDelete) {
      try {
        const response = await fetch(`${import.meta.env.VITE_API_URL}/maps/features/${featureId}`, {
          method: "DELETE",
        });
        if (!response.ok) console.error(`Failed to delete feature ${featureId}`);
      } catch (error) {
        console.error(`Error deleting feature ${featureId}:`, error);
      }
    }

    const remainingFeatures = props.features.filter((f) => !featuresToDelete.includes(f.id));
    emit("features-loaded", remainingFeatures);

    selectedFeatures.clear();
    updateFeatureSelectionVisual(map, featureLayerManager, selectedFeatures);
  }

  async function deleteFeature(featureId, featureLayerManager, map, emit) {
    const fid = String(featureId);

    const layer = featureLayerManager.layers.get(fid);
    if (layer) {
      map.removeLayer(layer);
      featureLayerManager.layers.delete(fid);
    }

    if (!fid.startsWith("temp_")) {
      try {
        const response = await fetch(`${import.meta.env.VITE_API_URL}/maps/features/${featureId}`, {
          method: "DELETE",
        });
        if (!response.ok) console.error(`Failed to delete feature ${featureId}`);
      } catch (error) {
        console.error(`Error deleting feature ${featureId}:`, error);
      }

      const remainingFeatures = props.features.filter((f) => f.id !== featureId);
      emit("features-loaded", remainingFeatures);
    }
  }

  function updateGeometryCoordinates(geometry, deltaLat, deltaLng) {
    if (!geometry || !geometry.coordinates) return geometry;

    const updatedGeometry = { ...geometry };

    switch (geometry.type) {
      case "Point":
        updatedGeometry.coordinates = [geometry.coordinates[0] + deltaLng, geometry.coordinates[1] + deltaLat];
        break;
      case "LineString":
        updatedGeometry.coordinates = geometry.coordinates.map((coord) => [coord[0] + deltaLng, coord[1] + deltaLat]);
        break;
      case "Polygon":
        updatedGeometry.coordinates = geometry.coordinates.map((ring) =>
          ring.map((coord) => [coord[0] + deltaLng, coord[1] + deltaLat])
        );
        break;
      default:
        return geometry;
    }

    return updatedGeometry;
  }

  function toggleDeleteMode() {
    if (props.activeEditMode === "DELETE_FEATURE") emit("mode-change", null);
    else emit("mode-change", "DELETE_FEATURE");
  }

  function startResizeShape() {
    isResizeMode.value = false;
    resizingShape.value = null;
    return false;
  }

  function updateResizeShape() {
    return null;
  }

  async function finishResizeShape() {
    isResizeMode.value = false;
    resizingShape.value = null;
    return;
  }

  function cancelResizeShape() {
    isResizeMode.value = false;
    resizingShape.value = null;
    return;
  }

  return {
    isDeleteMode,
    isResizeMode,
    resizingShape,

    createSquare,
    createRectangle,
    createCircle,
    createTriangle,
    createOval,
    createPointAt,
    createLine,
    createPolygon,
    finishFreeLine,

    updateTempSquareFromCenter,
    updateTempRectangleFromCorners,
    updateTempCircleFromCenter,
    updateTempTriangleFromCenter,
    updateTempOvalHeight,
    updateTempOvalWidth,

    squareToFeatureFromCenter,
    rectangleToFeatureFromCorners,
    circleToFeatureFromCenter,
    triangleToFeatureFromCenter,
    ovalToFeatureFromCenter,

    updateFeatureSelectionVisual,

    updateFeaturePosition,
    deleteSelectedFeatures,
    deleteFeature,
    updateGeometryCoordinates,

    toggleDeleteMode,

    startResizeShape,
    updateResizeShape,
    finishResizeShape,
    cancelResizeShape,

    smoothFreeLinePoints,

    applyResizeFromDims,

    // NEW
    applyRotateFromAngle,
  };
}

function getRadiusForZoom(currentZoom) {
  const BASE_ZOOM = 5;
  const BASE_RADIUS = 3;
  const ZOOM_FACTOR = 1.5;
  const zoomDiff = currentZoom - BASE_ZOOM;
  return Math.max(BASE_RADIUS, BASE_RADIUS * Math.pow(ZOOM_FACTOR, zoomDiff));
}
